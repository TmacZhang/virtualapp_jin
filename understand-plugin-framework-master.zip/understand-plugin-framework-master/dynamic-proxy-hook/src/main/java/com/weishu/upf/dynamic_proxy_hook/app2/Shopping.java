package com.weishu.upf.dynamic_proxy_hook.app2;

/**
 * @author weishu
 * @date 16/1/28
 */
public interface Shopping {
    Object[] doShopping(long money);
}
